#!/bin/bash
echo 'Setup kiosk placeholder'