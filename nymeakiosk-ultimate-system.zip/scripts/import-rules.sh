#!/bin/bash
echo 'Import rules placeholder'