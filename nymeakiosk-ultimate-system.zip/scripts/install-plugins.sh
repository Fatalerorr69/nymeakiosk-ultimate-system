#!/bin/bash
echo 'Install plugins placeholder'