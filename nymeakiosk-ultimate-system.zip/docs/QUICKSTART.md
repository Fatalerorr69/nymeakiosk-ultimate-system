# Quickstart

Tento dokument vás provede rychlým spuštěním systému.