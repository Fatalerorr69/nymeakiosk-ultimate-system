# Úprava SWAP nastavení
sudo nano /etc/dphys-swapfile

# Změna velikosti SWAP (pro RPi 4/5 s 2GB+ RAM)
CONF_SWAPSIZE=512