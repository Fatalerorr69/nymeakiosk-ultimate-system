# Spuštění skriptu pro instalaci pluginů
wget -O /tmp/plugins-setup.sh https://raw.githubusercontent.com/example/nymea-init/main/plugins-setup.sh
chmod +x /tmp/plugins-setup.sh
sudo /tmp/plugins-setup.sh