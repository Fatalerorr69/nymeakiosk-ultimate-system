# Spuštění optimalizačního skriptu
wget -O /tmp/optimization-setup.sh https://raw.githubusercontent.com/example/nymea-init/main/optimization-setup.sh
chmod +x /tmp/optimization-setup.sh
sudo /tmp/optimization-setup.sh