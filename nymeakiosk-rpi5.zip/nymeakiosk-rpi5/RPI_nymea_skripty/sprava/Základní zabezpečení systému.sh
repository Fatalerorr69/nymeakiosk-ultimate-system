# Spuštění bezpečnostního skriptu
wget -O /tmp/security-setup.sh https://raw.githubusercontent.com/example/nymea-init/main/security-setup.sh
chmod +x /tmp/security-setup.sh
sudo /tmp/security-setup.sh