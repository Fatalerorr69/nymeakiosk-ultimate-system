# Spuštění skriptu pro vzdálený přístup
wget -O /tmp/remote-access-setup.sh https://raw.githubusercontent.com/example/nymea-init/main/remote-access-setup.sh
chmod +x /tmp/remote-access-setup.sh
sudo /tmp/remote-access-setup.sh