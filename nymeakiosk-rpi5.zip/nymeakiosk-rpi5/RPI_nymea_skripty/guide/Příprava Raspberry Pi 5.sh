# Instalace základního OS
sudo apt-get update
sudo apt-get upgrade -y

# Instalace závislostí
sudo apt-get install -y git python3-pip docker.io docker-compose