# Průvodce pro učitele - Vzdělávací systém Raspberry Pi

## 📋 Úvod

Vítejte v komplexním vzdělávacím systému pro Raspberry Pi 5. Tento systém slouží k výuce programování, robotiky a IoT technologií.

## 🚀 Rychlý start

### Instalace systému
```bash
cd /home/education-system/bin
sudo ./system-setup.sh --role=teacher