# Přihlaste se a změňte heslo pro uživatele nymea
passwd