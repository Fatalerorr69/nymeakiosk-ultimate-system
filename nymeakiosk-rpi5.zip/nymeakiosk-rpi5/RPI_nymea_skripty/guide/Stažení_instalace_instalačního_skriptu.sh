# Stažení instalačního skriptu
wget https://example.com/rpi5-education-setup.sh

# Nastavení spustitelnosti
chmod +x rpi5-education-setup.sh

# Spuštění skriptu
sudo ./rpi5-education-setup.sh --role=teacher --project-focus=programming