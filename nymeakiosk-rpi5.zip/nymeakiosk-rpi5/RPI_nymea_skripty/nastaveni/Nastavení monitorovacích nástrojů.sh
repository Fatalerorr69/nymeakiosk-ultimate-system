# Spuštění monitorovacího skriptu
wget -O /tmp/monitoring-setup.sh https://raw.githubusercontent.com/example/nymea-init/main/monitoring-setup.sh
chmod +x /tmp/monitoring-setup.sh
sudo /tmp/monitoring-setup.sh