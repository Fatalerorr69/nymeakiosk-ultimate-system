# Nastavení časového pásma pro ČR
sudo timedatectl set-timezone Europe/Prague

# Nastavení jazyka a lokalizace
sudo localectl set-locale LANG=cs_CZ.UTF-8
sudo localectl set-keymap cz