# Přidání optimalizací do /etc/fstab
sudo nano /etc/fstab

# Přidejte tyto volby k vašim diskovým oddílům:
# defaults,noatime,nodiratime,commit=60