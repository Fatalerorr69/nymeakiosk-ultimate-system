# Instalace monitorovacích nástrojů
sudo apt-get install -y htop

# Sledování vytížení systému
htop