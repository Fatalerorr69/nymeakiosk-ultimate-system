# Úprava konfigurace pro otočení obrazovky
sudo nano /boot/config.txt

# Přidání řádku pro otočení (např. 90 stupňů)
display_rotate=1