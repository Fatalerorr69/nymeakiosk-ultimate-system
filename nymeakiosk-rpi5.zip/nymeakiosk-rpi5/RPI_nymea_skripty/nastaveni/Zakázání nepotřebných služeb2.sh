# Seznam a zastavení nepotřebných služeb
sudo systemctl stop bluetooth
sudo systemctl disable bluetooth
sudo systemctl stop avahi-daemon
sudo systemctl disable avahi-daemon