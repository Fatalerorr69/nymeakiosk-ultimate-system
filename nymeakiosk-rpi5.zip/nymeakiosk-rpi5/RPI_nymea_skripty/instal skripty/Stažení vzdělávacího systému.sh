# Naklonování repozitáře
git clone https://github.com/education-system/rpi5-education.git /home/education-system

# Nastavení oprávnění
chmod +x /home/education-system/bin/*.sh