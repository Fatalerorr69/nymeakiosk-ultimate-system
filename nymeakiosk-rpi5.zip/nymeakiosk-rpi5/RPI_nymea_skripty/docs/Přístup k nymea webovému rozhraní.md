Otevřete webový prohlížeč

Připojte se na adresu: http://ip-adresa-raspberry-pi

nebo: http://nymea.local (pokud podporuje vaše síť mDNS)