
### 5. Průvodce pro studenty (`/home/education-system/docs/student-guide.md`)
```markdown
# Průvodce pro studenty - Vzdělávací systém

## 🎯 Jak začít

### Přihlášení do systému
```bash
username: student_vasename
password: vygenerované_heslo