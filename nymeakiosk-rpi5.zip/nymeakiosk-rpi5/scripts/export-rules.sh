#!/bin/bash
echo 'Export rules placeholder'