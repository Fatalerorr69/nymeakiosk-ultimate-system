#!/bin/bash
echo 'Install Node-RED placeholder'